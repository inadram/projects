define(['app/show', 'lib/tabs'], function (Show, Tabs) {
	var show = new Show();
	var tabs = new Tabs();
});

