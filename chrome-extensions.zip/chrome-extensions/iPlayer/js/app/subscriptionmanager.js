define('app/subscriptionmanager',
	[
		'lib/class',
		'lib/domready'
	],
	function (Class, domReady) {
		var subscriptionManager = Class.extend({
			init: function () {
				this._attachEventListener();
			},

			_attachEventListener: function () {
				var self = this;
				domReady(function () {
					for (var item in localStorage) {
						if (item.substring(0, 'iplayer_'.length) === 'iplayer_') {
							document.getElementById('unSubscribe_' + item).addEventListener('click', self.unSubscribeClickHandler);
						}
					}
				});
			},

			unSubscribeClickHandler: function (e) {
				setTimeout(this.unSubscribe, 1000, e.target.id);
			},

			subscribeToCurrentProgramme: function () {
				localStorage.setItem("iplayer_" + localStorage.getItem('currentBrandTitle').replace(/\W/g, ''), localStorage.getItem('currentBrandId'));
			},

			unSubscribe: function (item) {
				item = item.replace('unSubscribe_', '');
				localStorage.removeItem(item);
				document.getElementById('li_' + item).remove();
				document.getElementById(item).remove();
				this.setActiveSubscription();
			},

			setActiveSubscription: function () {
				var firstTab = document.getElementsByTagName('li')[0];
				firstTab.setAttribute("class", "active");
			}

		});
		return subscriptionManager;

	});
