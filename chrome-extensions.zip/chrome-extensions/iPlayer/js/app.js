requirejs.config({
	"paths": {
		"jquery": "lib/jquery",
		"custom": "lib/custom"
	}
});

// Load the main app module to start the app
requirejs(["app/main"]);

define(['app/popup'],
	function (PopUp) {
		var popUp = new PopUp();
	});